/*:
# Case Study: Diagrams 

In this chapter, we'll look at a functional way to describe diagrams and discuss
how to draw them with Core Graphics. By wrapping Core Graphics with a functional
layer, we get an API that's simpler and more composable.

*/
