/*:
## Case Study: Traversing a Binary Tree

To illustrate sequences and iterators, we'll consider defining a traversal on a
binary tree. Recall our definition of binary trees from Chapter 9:

*/

//#-editable-code
indirect enum BinarySearchTree<Element: Comparable> {
    case leaf
    case node(BinarySearchTree<Element>, Element, BinarySearchTree<Element>)
}
//#-end-editable-code

/*:
We can use the append operator, `+`, which we defined for iterators earlier in
this chapter, to produce sequences of elements of a binary tree. For example,
the `inOrder` traversal visits the left subtree, the root, and the right
subtree, in that order:

*/

//#-hidden-code
func +<I: IteratorProtocol, J: IteratorProtocol>(
    first: I, second: @escaping @autoclosure () -> J)
    -> AnyIterator<I.Element> where I.Element == J.Element
{
    var one = first
    var other: J? = nil
    return AnyIterator {
        if other != nil {
            return other!.next()
        } else if let result = one.next() {
            return result
        } else {
            other = second()
            return other!.next()
        }
    }
}
//#-end-hidden-code

//#-editable-code
extension BinarySearchTree: Sequence {
    func makeIterator() -> AnyIterator<Element> {
        switch self {
        case .leaf: return AnyIterator { return nil }
        case let .node(l, element, r):
            return l.makeIterator() + CollectionOfOne(element).makeIterator() +
                r.makeIterator()
        }
    }
}
//#-end-editable-code

/*:
If the tree has no elements, we return an empty iterator. If the tree has a
node, we combine the results of the two recursive calls, together with the
single value stored at the root, using the append operator on iterators.
`CollectionOfOne` is a type from the standard library. Note that we defined `+`
in a lazy way. If we would've used the first (eager) definition of `+`, the
`makeIterator` method would've visited the entire tree before returning.

*/
