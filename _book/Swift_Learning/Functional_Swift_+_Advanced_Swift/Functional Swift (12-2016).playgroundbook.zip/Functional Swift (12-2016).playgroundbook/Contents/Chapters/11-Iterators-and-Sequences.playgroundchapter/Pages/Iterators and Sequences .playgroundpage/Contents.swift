/*:
# Iterators and Sequences 

In this chapter, we'll look at iterators and sequences, which form the machinery
underlying Swift's `for` loops.

*/
