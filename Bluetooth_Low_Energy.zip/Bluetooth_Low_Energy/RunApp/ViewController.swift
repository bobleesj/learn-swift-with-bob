//
//  ViewController.swift
//  RunApp
//
//  Created by Bob Lee on 2/3/17.
//  Copyright © 2017 BobtheDeveloper. All rights reserved.
//

import UIKit
import CoreBluetooth

class ViewController: UIViewController, CBPeripheralDelegate, CBCentralManagerDelegate {
 
  
  var manager: CBCentralManager!
  var peripheral: CBPeripheral!
  

  /*
  let BEAN_NAME = "Robu"
  let BEAN_SCRATCH_UUID =
    CBUUID(string: "a495ff21-c5b1-4b44-b512-1370f02d74de")
  let BEAN_SERVICE_UUID =
    CBUUID(string: "a495ff20-c5b1-4b44-b512-1370f02d74de")
 */

  
  override func viewDidLoad() {
    super.viewDidLoad()
    // Do any additional setup after loading the view, typically from a nib.
    manager = CBCentralManager(delegate: self, queue: nil)
  }
  
  // Every time get discovered, this call back runs. It returns as CBPeripheral object
  func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber) {
    print("Discovered \(peripheral.name)")
    self.peripheral = peripheral
    manager.connect(peripheral, options: nil)
    
    // If the connection is successful, it call a delegat method, didConnectPeripheral
  }
  
  func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
    print("Peripheral Connected")
    peripheral.delegate = self
    print("You are connected with, \(peripheral.name)")
    print(peripheral.services)
    print(peripheral.readRSSI())
    
    // Once connected, the peripheral calles the peripheral:didDiscoverSrevices of the delegate object and create an array of CBServices objects
  }
  
  func centralManagerDidUpdateState(_ central: CBCentralManager) {
    if central.state == .poweredOn {
      central.scanForPeripherals(withServices: nil, options: nil)
    } else {
      print("Bluetooth not available")
    }
    
  }
  
  
  // 1. Peripheral Object Finding Services
  func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
    print("Trying to find out if there is any service")
    for service: CBService in peripheral.services! {
      print(service)
    }
  }
  
  
  // 2. Peripheral Object Finding Characteristics
  func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
    for character: CBCharacteristic in service.characteristics! {
      print(character)
    }
  }
  
}
